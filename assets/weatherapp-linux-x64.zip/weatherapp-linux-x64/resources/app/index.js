const electron = require('electron');
const {ipcRenderer} = electron;
let request = require('request');
var weekday = require('weekday');

// get the cityName value
let cityName = document.querySelector('#cityName')



let apiKey = '3bce864f036c646f04fe36e5988b1443';
let city = cityName.getAttribute('value');
// you can set the f, c or k for temp in api call.
let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`

request(url, function (err, response, body) {
// error check
  if(err){
    console.log('error:', error);
  }
  // JSON.parse the object passed back to use by the api call
  else {
    let list = JSON.parse(body);
    require('dotenv').config();
  console.log('Your environment variable TWILIO_ACCOUNT_SID has the value: ', process.env.TWILIO_ACCOUNT_SID);


    let roundTemp = Math.round(list.main.temp)
    let tempNode = document.createTextNode(roundTemp + String.fromCharCode(176));
    let temp = document.querySelector('#show');
    temp.appendChild(tempNode);

    // set the day for today
    let day = document.querySelector('#today');
    let dayNode = document.createTextNode(weekday());
    day.appendChild(dayNode);


        let cloudsNode = document.createTextNode(list.weather[0].main);
        let clouds = document.querySelector('#clouds');
        clouds.appendChild(cloudsNode);
  }
});

const background = document.querySelector('body');
